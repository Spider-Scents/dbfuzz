## Versions

Text_Diff: https://github.com/horde/Text_Diff/releases/tag/v2.2.1

Util: https://github.com/horde/Util/releases/tag/v2.5.9
