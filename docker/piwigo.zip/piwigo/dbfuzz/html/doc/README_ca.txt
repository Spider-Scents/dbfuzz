=======
Piwigo
=======

Lloc Web:       http://piwigo.org
Instal·lació:   http://piwigo.org/basics/installation
Actualització:  http://piwigo.org/basics/upgrade

Com començar
============

Un cop instal·lat o actualitzat, la galeria està a punt per funcionar. 
Situa't al directori d'instal·lació del teu navegador:

http://el.teu.domini/photos

A continuació, identifica't com a administrador. Apareixerà un nou enllaç 
a la pàgina del menú d'identificació: Administració. Aneu al panell d'administració.

Al panell d'administració, pren-te tot el temps que et calgui per llegir 
detingudament les instruccions que expliquen com utilitzar la galeria PIWIGO.

Comunicació
=============

Butlletí de notícies
--------------------

http://piwigo.org/basics/newsletter

És *altament* recomanable inscriu-re's al butlletí de Piwigo.
Tot i què aqusta secció té poquíssim moviment, podràs assabentar-te
de la notificació d'errors greus o del llançament de noves versions de Piwigo.

Estigues al dia
---------------

http://freecode.com/projects/piwigo

Mantinguet informat per a cada nova versió, tant estable com en desenvolupament.
El butlletí de notícies no envia notificacions de les versions en desenvolupament.

Registre d'errors
-----------------

http://piwigo.org/bugs

Errors i registre i seguiment de canvis. La millor forma de tindre els errors corregits:
No te n'oblidis. (així com el fòrum).

Documentació
------------

http://piwigo.org/doc

Documentació Wiki: Tothom pot participar per millorar el contingut de la documentació.

Fòrum
-----

http://piwigo.org/forum
