<?php
$dbuser="root";
$dbpass="notSecureChangeMe";
$host="mariadb";
$db="hostel";
$mysqli =new mysqli($host,$dbuser, $dbpass, $db);
?>