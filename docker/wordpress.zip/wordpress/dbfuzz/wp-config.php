<?php
/**
 * The base configuration for WordPress
 *
 * The wp-config.php creation script uses this file during the installation.
 * You don't have to use the web site, you can copy this file to "wp-config.php"
 * and fill in the values.
 *
 * This file contains the following configurations:
 *
 * * Database settings
 * * Secret keys
 * * Database table prefix
 * * ABSPATH
 *
 * @link https://wordpress.org/support/article/editing-wp-config-php/
 *
 * @package WordPress
 */

// ** Database settings - You can get this info from your web host ** //
/** The name of the database for WordPress */
define( 'DB_NAME', 'wordpress' );

/** Database username */
define( 'DB_USER', 'root' );

/** Database password */
define( 'DB_PASSWORD', 'notSecureChangeMe' );

/** Database hostname */
define( 'DB_HOST', 'mariadb' );

/** Database charset to use in creating database tables. */
define( 'DB_CHARSET', 'utf8mb4' );

/** The database collate type. Don't change this if in doubt. */
define( 'DB_COLLATE', '' );

/**#@+
 * Authentication unique keys and salts.
 *
 * Change these to different unique phrases! You can generate these using
 * the {@link https://api.wordpress.org/secret-key/1.1/salt/ WordPress.org secret-key service}.
 *
 * You can change these at any point in time to invalidate all existing cookies.
 * This will force all users to have to log in again.
 *
 * @since 2.6.0
 */
define( 'AUTH_KEY',         'heUa=q|5wntam2?lty`rG5r>m8{|lEitg=-XzDDVhTpM9#u$e05; :gy?D_OrMs8' );
define( 'SECURE_AUTH_KEY',  'c-]{wvh-GltHZa!J$~QobPlQq?<6j,jyt4FiyK3lhHRgN]:j_$:<kvtz!9>sw7e.' );
define( 'LOGGED_IN_KEY',    ']lJidYP_Gsr4JPGh/6Ffq+EpRKwA),R5^o@7NvrXmPK4yrU5qGouIcd<.hW&S&pc' );
define( 'NONCE_KEY',        '/!L _sC&|1iKTltf{;s[V5XoBrpIjI.Y&?O:eZRBIb)s 0%uQ<x>QlNq)~x%,t<!' );
define( 'AUTH_SALT',        '00dDf{|RyU!Z;9=w:)1N?6l>>3Y*LNEEzqy*4M{d56?dl-DKN5.Vg*WMZ!.ElWuv' );
define( 'SECURE_AUTH_SALT', ';/l!Y:J/_KMTm=++P?m.elvG;Q$}d>aNV`=F#MX*/O)bP5_FWiti8m*-[OM5wb,m' );
define( 'LOGGED_IN_SALT',   '$h1;*z;QyT2*=APJ#AV%Y*[uru`G0wXJs+&@P^Jo*;Pu.Z,:%}g[jaIh1iYNY,8a' );
define( 'NONCE_SALT',       ').-*dwB&<D+.[<4S6HbI{bwp&SdjuV7Dm?wk?.ppy]dtEh+wqY<j27nny|uAokE8' );

/**#@-*/

/**
 * WordPress database table prefix.
 *
 * You can have multiple installations in one database if you give each
 * a unique prefix. Only numbers, letters, and underscores please!
 */
$table_prefix = 'wp_';

/**
 * For developers: WordPress debugging mode.
 *
 * Change this to true to enable the display of notices during development.
 * It is strongly recommended that plugin and theme developers use WP_DEBUG
 * in their development environments.
 *
 * For information on other constants that can be used for debugging,
 * visit the documentation.
 *
 * @link https://wordpress.org/support/article/debugging-in-wordpress/
 */
define( 'WP_DEBUG', false );

/* Add any custom values between this line and the "stop editing" line. */



/* That's all, stop editing! Happy publishing. */

/** Absolute path to the WordPress directory. */
if ( ! defined( 'ABSPATH' ) ) {
	define( 'ABSPATH', __DIR__ . '/' );
}

/** Sets up WordPress vars and included files. */
require_once ABSPATH . 'wp-settings.php';
