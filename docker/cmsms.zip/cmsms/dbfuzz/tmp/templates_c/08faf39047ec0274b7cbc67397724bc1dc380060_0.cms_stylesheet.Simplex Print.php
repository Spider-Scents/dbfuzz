<?php
/* Smarty version 3.1.31, created on 2024-06-07 10:39:59
  from "cms_stylesheet:Simplex Print" */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '3.1.31',
  'unifunc' => 'content_6662e37f594266_69018288',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    '08faf39047ec0274b7cbc67397724bc1dc380060' => 
    array (
      0 => 'cms_stylesheet:Simplex Print',
      1 => '1676610484',
      2 => 'cms_stylesheet',
    ),
  ),
  'includes' => 
  array (
  ),
),false)) {
function content_6662e37f594266_69018288 (Smarty_Internal_Template $_smarty_tpl) {
?>
/* cmsms stylesheet: Simplex Print modified: Friday, February 17, 2023 5:08:04 AM */
body {background: #fff;color: #000;font-family: Georgia, Times New Roman, serif;font-size: 12pt}.noprint,.visuallyhidden {display: none}img {display: block;float: none}a:link:after {content: " (" attr(href) ") ";}a {text-decoration: underline}
<?php }
}
