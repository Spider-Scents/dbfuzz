<?php
/* Smarty version 3.1.31, created on 2024-06-07 10:39:56
  from "cms_template:notemplate" */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '3.1.31',
  'unifunc' => 'content_6662e37ca66892_34589666',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    '690d404c76251d1509568efadb399487d4882656' => 
    array (
      0 => 'cms_template:notemplate',
      1 => 1717756796,
      2 => 'cms_template',
    ),
  ),
  'includes' => 
  array (
  ),
),false)) {
function content_6662e37ca66892_34589666 (Smarty_Internal_Template $_smarty_tpl) {
CMS_Content_Block::smarty_internal_fetch_contentblock(array(),$_smarty_tpl);
}
}
