<?php
// Text
$_['text_price'] = 'Price:';
$_['text_tax']   = 'Ex Tax:';